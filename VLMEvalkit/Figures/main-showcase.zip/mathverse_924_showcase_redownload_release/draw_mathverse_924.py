#!/usr/bin/env python3
"""Rebuild the MathVerse #924 showcase.

The table, callout, highlights, and labels are drawn as SVG primitives/live text.
The problem diagram in the top-right is inserted from the user-provided diagram
crop to avoid geometry drift from manual redrawing. The final page is not a
full-page screenshot: only that small diagram crop is raster; the rest remains
vector/text.

Dependencies: pillow and cairosvg. Inkscape is preferred for PDF export.
"""
from __future__ import annotations

import base64
import json
import math
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from html import escape
from pathlib import Path
from typing import Any, Iterable

try:
    from PIL import ImageFont
except ImportError as exc:  # pragma: no cover
    raise SystemExit("This script requires Pillow: pip install pillow") from exc

try:
    import cairosvg
except ImportError:  # pragma: no cover
    cairosvg = None

font_manager = None  # matplotlib is intentionally not required for this asset rebuild.

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
OUT = ROOT / "outputs"
DATA_PATH = ASSETS / "figure_data.json"
SVG_PATH = OUT / "mathverse_924_showcase_token_omit_redownload.svg"
SVG_OUTLINE_PATH = OUT / "mathverse_924_showcase_token_omit_redownload_outlined.svg"
PDF_PATH = OUT / "mathverse_924_showcase_token_omit_redownload.pdf"

FONT_FAMILY = "Comic Neue"
SERIF_FAMILY = "STIX"
FONT_STACK = "'Comic Neue', 'DejaVu Sans', 'Comic Sans MS', 'Chalkboard SE', cursive"
SERIF_STACK = "'STIX', 'Times New Roman', serif"


def find_font(family: str, weight: str = "regular", style: str = "normal") -> str | None:
    """Find a local font file for measurement only. No font file is embedded or copied."""
    # Strong defaults in this environment. They are harmless if absent elsewhere.
    candidates = []
    if family.lower() == "comic neue":
        base = Path("/usr/share/fonts/opentype/comic-neue")
        if weight in {"bold", "700"} and style == "italic":
            candidates.append(base / "ComicNeue-BoldItalic.otf")
        elif weight in {"bold", "700"}:
            candidates.append(base / "ComicNeue-Bold.otf")
        elif style == "italic":
            candidates.append(base / "ComicNeue-Italic.otf")
        else:
            candidates.append(base / "ComicNeue-Regular.otf")
    if family.lower() == "stix":
        candidates.extend(Path("/usr/share/fonts/opentype/stix-word").glob("STIX-*.otf"))
        candidates.extend(Path("/usr/share/fonts/opentype/stix").glob("STIX*.otf"))
    for c in candidates:
        if c.exists():
            return str(c)

    if font_manager is not None:
        try:
            props = font_manager.FontProperties(family=family, weight=weight, style=style)
            fp = font_manager.findfont(props, fallback_to_default=True)
            return fp if Path(fp).exists() else None
        except Exception:
            return None
    return None


@dataclass
class FontCache:
    cache: dict[tuple[str, int, str, str], Any] = field(default_factory=dict)

    def get(self, family: str, size: int, weight: str = "regular", style: str = "normal"):
        key = (family, size, weight, style)
        if key not in self.cache:
            font_path = find_font(family, weight, style)
            if font_path:
                self.cache[key] = ImageFont.truetype(font_path, size)
            else:
                self.cache[key] = ImageFont.load_default(size=size)
        return self.cache[key]

    def width(self, text: str, size: int, weight: str = "regular", family: str = FONT_FAMILY, style: str = "normal") -> float:
        if not text:
            return 0.0
        font = self.get(family, int(round(size)), weight, style)
        # getlength is available for FreeTypeFont and preserves spaces.
        return float(font.getlength(text))


fonts = FontCache()


class SVG:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.parts: list[str] = []
        self.defs: list[str] = []

    def add(self, s: str) -> None:
        self.parts.append(s)

    def add_def(self, s: str) -> None:
        self.defs.append(s)

    def attrs(self, attrs: dict[str, Any]) -> str:
        out = []
        for k, v in attrs.items():
            if v is None:
                continue
            out.append(f'{k.replace("_", "-")}="{escape(str(v), quote=True)}"')
        return " ".join(out)

    def rect(self, x: float, y: float, w: float, h: float, fill: str = "none", stroke: str = "none",
             sw: float = 1.0, rx: float = 0, opacity: float | None = None, **kw) -> None:
        attrs = dict(x=fmt(x), y=fmt(y), width=fmt(w), height=fmt(h), fill=fill, stroke=stroke,
                     **{"stroke-width": fmt(sw)}, rx=fmt(rx), ry=fmt(rx), opacity=opacity, **kw)
        self.add(f'<rect {self.attrs(attrs)}/>' )

    def line(self, x1: float, y1: float, x2: float, y2: float, stroke: str = "#111", sw: float = 1.0,
             dash: str | None = None, cap: str = "butt", opacity: float | None = None) -> None:
        attrs = dict(x1=fmt(x1), y1=fmt(y1), x2=fmt(x2), y2=fmt(y2), stroke=stroke,
                     **{"stroke-width": fmt(sw), "stroke-linecap": cap, "stroke-dasharray": dash, "opacity": opacity})
        self.add(f'<line {self.attrs(attrs)}/>' )

    def polyline(self, pts: Iterable[tuple[float, float]], fill: str = "none", stroke: str = "#111", sw: float = 1.0,
                 close: bool = False, cap: str = "round", join: str = "round", dash: str | None = None) -> None:
        pts_s = " ".join(f"{fmt(x)},{fmt(y)}" for x, y in pts)
        name = "polygon" if close else "polyline"
        attrs = dict(points=pts_s, fill=fill, stroke=stroke, **{"stroke-width": fmt(sw), "stroke-linecap": cap,
                     "stroke-linejoin": join, "stroke-dasharray": dash})
        self.add(f'<{name} {self.attrs(attrs)}/>' )

    def circle(self, cx: float, cy: float, r: float, fill: str = "none", stroke: str = "#111", sw: float = 1.0,
               opacity: float | None = None) -> None:
        attrs = dict(cx=fmt(cx), cy=fmt(cy), r=fmt(r), fill=fill, stroke=stroke,
                     **{"stroke-width": fmt(sw), "opacity": opacity})
        self.add(f'<circle {self.attrs(attrs)}/>' )

    def ellipse(self, cx: float, cy: float, rx: float, ry: float, fill: str = "none", stroke: str = "#111", sw: float = 1.0) -> None:
        attrs = dict(cx=fmt(cx), cy=fmt(cy), rx=fmt(rx), ry=fmt(ry), fill=fill, stroke=stroke, **{"stroke-width": fmt(sw)})
        self.add(f'<ellipse {self.attrs(attrs)}/>' )

    def image(self, x: float, y: float, w: float, h: float, href: str, opacity: float | None = None,
              preserve_aspect_ratio: str = "meet") -> None:
        attrs = dict(x=fmt(x), y=fmt(y), width=fmt(w), height=fmt(h), href=href,
                     preserveAspectRatio=f"xMidYMid {preserve_aspect_ratio}", opacity=opacity)
        self.add(f'<image {self.attrs(attrs)}/>')

    def path(self, d: str, fill: str = "none", stroke: str = "#111", sw: float = 1.0,
             cap: str = "round", join: str = "round", opacity: float | None = None) -> None:
        attrs = dict(d=d, fill=fill, stroke=stroke, **{"stroke-width": fmt(sw), "stroke-linecap": cap,
                     "stroke-linejoin": join, "opacity": opacity})
        self.add(f'<path {self.attrs(attrs)}/>' )

    def text(self, x: float, y: float, text: str, size: int = 24, fill: str = "#111", weight: str = "bold",
             family: str = FONT_STACK, style: str = "normal", anchor: str = "start", opacity: float | None = None,
             extra: dict[str, Any] | None = None) -> None:
        attrs = dict(x=fmt(x), y=fmt(y), fill=fill, **{"font-size": size, "font-family": family,
                     "font-weight": weight, "font-style": style, "text-anchor": anchor,
                     "xml:space": "preserve", "opacity": opacity})
        if extra:
            attrs.update(extra)
        self.add(f'<text {self.attrs(attrs)}>{escape(text)}</text>')

    def group_start(self, **attrs) -> None:
        self.add(f'<g {self.attrs(attrs)}>')

    def group_end(self) -> None:
        self.add('</g>')

    def tostring(self) -> str:
        css = f"""
        <style><![CDATA[
          * {{ vector-effect: none; }}
          text {{ text-rendering: geometricPrecision; }}
          .comic {{ font-family: {FONT_STACK}; }}
          .serif {{ font-family: {SERIF_STACK}; }}
        ]]></style>
        """
        defs = "\n".join(self.defs)
        content = "\n".join(self.parts)
        return (f'<?xml version="1.0" encoding="UTF-8"?>\n'
                f'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" '
                f'width="{self.width}" height="{self.height}" viewBox="0 0 {self.width} {self.height}">\n'
                f'<defs>{defs}</defs>\n{css}\n{content}\n</svg>\n')


def fmt(v: float | int | str) -> str:
    if isinstance(v, str):
        return v
    if abs(float(v) - round(float(v))) < 1e-6:
        return str(int(round(float(v))))
    return f"{float(v):.2f}".rstrip("0").rstrip(".")


def lighten(hex_color: str, amount: float = 0.85) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    r = int(r + (255 - r) * amount)
    g = int(g + (255 - g) * amount)
    b = int(b + (255 - b) * amount)
    return f"#{r:02x}{g:02x}{b:02x}"


def add_line_segments(svg: SVG, x: float, y: float, segments: list[dict[str, Any]], *, size: int = 24,
                      default_fill: str = "#111", default_weight: str = "bold", line_height: float = 32,
                      family: str = FONT_STACK, measure_family: str = FONT_FAMILY) -> None:
    """Draw one manually wrapped line with per-span color/highlight."""
    cx = x
    for seg in segments:
        text = seg.get("text", "")
        fill = seg.get("color", default_fill)
        weight = "bold" if seg.get("bold", True) else "regular"
        style = seg.get("style", "normal")
        highlight = seg.get("highlight")
        measure_weight = "bold" if weight in {"bold", "700"} else "regular"
        width = fonts.width(text, size, measure_weight, FONT_FAMILY, style)
        if highlight:
            bg = "#ffe78a" if highlight == "yellow" else "#c8e6c9"
            pad_x = 4
            h = size * 1.03
            svg.rect(cx - pad_x, y - size * 0.82, width + 2 * pad_x, h, fill=bg,
                     stroke="none", sw=0, rx=3)
        svg.text(cx, y, text, size=size, fill=fill, weight=weight, family=family, style=style)
        cx += width


def draw_robot(svg: SVG, cx: float, cy: float, color: str) -> None:
    fill = lighten(color, 0.90)
    sw = 3.2
    # antenna
    svg.line(cx, cy - 26, cx, cy - 38, stroke=color, sw=sw, cap="round")
    svg.circle(cx, cy - 43, 4.5, fill="#ffffff", stroke=color, sw=sw)
    # ears
    svg.rect(cx - 32, cy - 6, 7, 19, fill=fill, stroke=color, sw=sw, rx=3)
    svg.rect(cx + 25, cy - 6, 7, 19, fill=fill, stroke=color, sw=sw, rx=3)
    # head
    svg.rect(cx - 25, cy - 22, 50, 40, fill=fill, stroke=color, sw=sw, rx=8)
    # face
    svg.circle(cx - 10, cy - 3, 3.2, fill=color, stroke="none")
    svg.circle(cx + 10, cy - 3, 3.2, fill=color, stroke="none")
    svg.line(cx - 9, cy + 10, cx + 9, cy + 10, stroke=color, sw=2.6, cap="round")
    # small feet
    svg.line(cx - 14, cy + 21, cx - 14, cy + 25, stroke=color, sw=sw, cap="round")
    svg.line(cx + 14, cy + 21, cx + 14, cy + 25, stroke=color, sw=sw, cap="round")


def draw_eye(svg: SVG, cx: float, cy: float, color: str) -> None:
    sw = 3.0
    d = f"M {fmt(cx-29)} {fmt(cy)} C {fmt(cx-18)} {fmt(cy-20)}, {fmt(cx+18)} {fmt(cy-20)}, {fmt(cx+30)} {fmt(cy)} C {fmt(cx+18)} {fmt(cy+20)}, {fmt(cx-18)} {fmt(cy+20)}, {fmt(cx-29)} {fmt(cy)} Z"
    svg.path(d, fill=lighten(color, 0.92), stroke=color, sw=sw)
    svg.circle(cx, cy, 11, fill="#ffffff", stroke=color, sw=sw)
    svg.circle(cx, cy, 4.2, fill=color, stroke="none")


def draw_check(svg: SVG, cx: float, cy: float, color: str = "#3fb15b") -> None:
    svg.circle(cx, cy, 27, fill="#ffffff", stroke=color, sw=5)
    svg.path(f"M {fmt(cx-14)} {fmt(cy-1)} L {fmt(cx-3)} {fmt(cy+11)} L {fmt(cx+16)} {fmt(cy-15)}",
             fill="none", stroke=color, sw=6, cap="round", join="round")


def png_data_uri(path: Path) -> str:
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:image/png;base64,{data}"


def draw_geometry_diagram(svg: SVG, x0: float = 1436, y0: float = 9) -> None:
    """Place the exact user-provided problem diagram crop inside the top panel."""
    svg.image(x0, y0, 466, 280, png_data_uri(ASSETS / "problem_diagram_exact_crop.png"), preserve_aspect_ratio="meet")


def draw_top(svg: SVG, data: dict[str, Any]) -> None:
    top = data["top"]
    # outer top panel
    svg.rect(4, 3, 2040, 291, fill="#ffffff", stroke="#d9e8f8", sw=2.0, rx=18)
    # left text
    svg.text(42, 55, top["problem_lines"][0], size=36, fill="#111111", weight="bold")
    svg.text(42, 111, top["problem_lines"][1], size=34, fill="#111111", weight="bold")
    svg.text(42, 161, top["problem_lines"][2], size=34, fill="#111111", weight="bold")
    # choices
    y = 246
    svg.text(42, y, "Choices:", size=34, fill="#111111", weight="bold")
    svg.text(195, y, "A. 7", size=34, fill="#111111", weight="bold")
    svg.rect(312, 208, 105, 54, fill="#ffffff", stroke="#4dbb75", sw=2.2, rx=8)
    svg.text(336, y, "B. 8", size=34, fill="#111111", weight="bold")
    svg.text(472, y, "C. 9", size=34, fill="#111111", weight="bold")
    svg.text(608, y, "D. 10", size=34, fill="#111111", weight="bold")
    # callout
    svg.rect(826, 27, 468, 245, fill="#fffefa", stroke="#f0b44e", sw=2.0, rx=10)
    svg.text(847, 66, top["callout_title"], size=26, fill="#111111", weight="bold")
    by = 111
    for i, bullet in enumerate(top["callout_bullets"]):
        yy = by + i * 39
        svg.text(850, yy, "•", size=26, fill="#111111", weight="bold")
        svg.text(889, yy, bullet, size=26, fill="#111111", weight="bold")
    svg.text(909, 250, top["ground_truth"], size=29, fill="#177b24", weight="bold")
    draw_geometry_diagram(svg)


def compute_table_geometry(data: dict[str, Any]) -> tuple[int, list[int]]:
    y0 = 306
    header_h = 53
    body_size = 24
    lh = 27
    row_ys = [y0 + header_h]
    for idx, row in enumerate(data["rows"]):
        n_mid = len(row.get("mid", []))
        n_right = len(row.get("right", []))
        # first baseline at y+31; leave room for descenders and card padding
        needed_mid = 31 + max(0, n_mid - 1) * lh + body_size + 14
        needed_right = 38 + max(1, n_right) * 34 + 16
        min_h = 74 if idx == 0 else 112
        row_ys.append(row_ys[-1] + int(max(min_h, needed_mid, needed_right)))
    return row_ys[-1] - y0, row_ys


def draw_table(svg: SVG, data: dict[str, Any]) -> None:
    # Two-column layout: model names are embedded at the start of each output cell.
    x0, y0 = 4, 306
    W = 2040
    out_w, right_w = 1538, 502
    x_out = x0
    x_right = x0 + out_w
    x_end = x0 + W
    header_h = 53
    H, row_ys = compute_table_geometry(data)

    svg.rect(x0, y0, W, H, fill="#ffffff", stroke="#dce9f6", sw=2.0, rx=13)
    svg.rect(x_out, y0, out_w, header_h, fill="#fbfdff", stroke="#dce9f6", sw=1.7, rx=0)
    svg.rect(x_right, y0, right_w, header_h, fill="#fbfdff", stroke="#dce9f6", sw=1.7, rx=0)
    svg.text(x_out + out_w/2, y0 + 36, "Raw Model Output", size=28, fill="#111111", weight="bold", anchor="middle")
    svg.text(x_right + right_w / 2, y0 + 36, "Key Behavior Highlight", size=27, fill="#111111", weight="bold", anchor="middle")

    rows = data["rows"]
    body_size = 24
    body_lh = 27
    label_size = 25
    sub_size = 21
    for idx, row in enumerate(rows):
        y1 = row_ys[idx]
        y2 = row_ys[idx + 1]
        h = y2 - y1
        svg.rect(x_out + 5, y1 + 2, out_w - 10, h - 4, fill=row.get("mid_tint", "#ffffff"), stroke="#e0e9f2", sw=1.2, rx=8)
        svg.rect(x_right + 5, y1 + 2, right_w - 10, h - 4, fill=row.get("right_tint", "#ffffff"), stroke="#e0e9f2", sw=1.2, rx=8)
        svg.line(x0, y1, x_end, y1, stroke="#dce9f6", sw=1.4)

        lab = row["label"]
        color = lab["color"]
        line_y = y1 + 31
        left_x = x_out + 25

        # First output line begins immediately after the colored model label.
        svg.text(left_x, line_y, lab["title"], size=label_size, fill=color, weight="bold")
        title_w = fonts.width(lab["title"], label_size, "bold", FONT_FAMILY)
        sub_x = left_x + title_w + 9
        svg.text(sub_x, line_y, lab["subtitle"], size=sub_size, fill="#111111", weight="bold")
        sub_w = fonts.width(lab["subtitle"], sub_size, "bold", FONT_FAMILY)
        content_x = sub_x + sub_w + 18
        mid_lines = row["mid"]
        if mid_lines:
            add_line_segments(svg, content_x, line_y, mid_lines[0], size=body_size, line_height=body_lh)
            for j, line in enumerate(mid_lines[1:], start=1):
                add_line_segments(svg, left_x, line_y + j * body_lh, line, size=body_size, line_height=body_lh)

        right_lines = row["right"]
        if idx == 8:
            draw_check(svg, x_right + 58, y1 + h / 2 + 2, "#44b35f")
            rx = x_right + 106
            ry = y1 + h / 2 - 15
        elif idx == 0:
            rx = x_right + 30
            ry = y1 + h / 2 + 9
        elif len(right_lines) == 1:
            rx = x_right + 30
            ry = y1 + h / 2 + 11
        else:
            rx = x_right + 30
            ry = y1 + h / 2 - 12
        right_size = 24 if idx not in (0, 8) else 23
        for j, line in enumerate(right_lines):
            add_line_segments(svg, rx, ry + j * 35, line, size=right_size, line_height=33)

    svg.line(x_right, y0, x_right, y0 + H, stroke="#dce9f6", sw=1.5)


def build_svg(data: dict[str, Any]) -> str:
    width = data["canvas"]["width"]
    table_h, _ = compute_table_geometry(data)
    height = max(data["canvas"].get("height", 0), 306 + table_h + 5)
    svg = SVG(width, height)
    svg.add_def('<linearGradient id="paper" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#fcfdff"/></linearGradient>')
    svg.rect(0, 0, width, height, fill="url(#paper)", stroke="none", sw=0)
    draw_top(svg, data)
    draw_table(svg, data)
    return svg.tostring()


def export_files(svg_text: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    SVG_PATH.write_text(svg_text, encoding="utf-8")

    # Prefer Inkscape for PDF export because it handles per-glyph font fallback
    # better for symbols in the raw model outputs (for example: ⟂, →, √, ²).
    inkscape = shutil.which("inkscape")
    if inkscape:
        subprocess.run([
            inkscape, str(SVG_PATH), "--export-type=pdf", f"--export-filename={PDF_PATH}"
        ], check=True)
        subprocess.run([
            inkscape, str(SVG_PATH), "--export-type=svg", f"--export-filename={SVG_OUTLINE_PATH}",
            "--export-text-to-path"
        ], check=True)
    elif cairosvg is not None:
        cairosvg.svg2pdf(bytestring=svg_text.encode("utf-8"), write_to=str(PDF_PATH))
    else:  # pragma: no cover
        print("Wrote SVG only. Install CairoSVG or Inkscape for PDF export.", file=sys.stderr)


def main() -> None:
    data = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    svg_text = build_svg(data)
    export_files(svg_text)
    print(f"Wrote {SVG_PATH}")
    if SVG_OUTLINE_PATH.exists():
        print(f"Wrote {SVG_OUTLINE_PATH}")
    if PDF_PATH.exists():
        print(f"Wrote {PDF_PATH}")


if __name__ == "__main__":
    main()
